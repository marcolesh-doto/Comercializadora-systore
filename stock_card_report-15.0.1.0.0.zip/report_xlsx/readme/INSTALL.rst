Make sure you have ``xlsxwriter`` Python module installed::

$ pip3 install xlsxwriter

For testing it is also necessary ``xlrd`` Python module installed::

$ pip3 install xlrd
